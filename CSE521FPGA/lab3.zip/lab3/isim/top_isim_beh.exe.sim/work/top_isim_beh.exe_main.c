/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00773189936389115535_3679546882_init();
    work_m_00773189936389115535_1510012899_init();
    work_m_16115074493021036697_2405636996_init();
    work_m_12096980637284896768_0376064574_init();
    work_m_07884961344999616315_3823007873_init();
    work_m_16541823861846354283_2073120511_init();


    xsi_register_tops("work_m_07884961344999616315_3823007873");
    xsi_register_tops("work_m_16541823861846354283_2073120511");


    return xsi_run_simulation(argc, argv);

}
